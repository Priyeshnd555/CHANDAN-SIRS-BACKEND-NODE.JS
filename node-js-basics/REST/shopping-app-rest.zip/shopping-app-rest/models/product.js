// to connect to the database
const mongoose=require("mongoose");

//to include the structure in the database
const Schema=mongoose.Schema;

//creating the structure to store data
const productSchema=new Schema({
    pName:{
        required:true,
        type:String,
        minlength:3,
        maxlength:100,
    },
    pDesc:{
        required:true,
        type:String,
        minlength:3,
        maxlength:100,
    },
    pPrice:{
        required:true,
        type:String,
        min:3,
        max:100000,
    },
    date:{
        type:Date,
        default:Date.now(),
    },
})
module.exports=mongoose.model("products",productSchema)
//in this first parameter is collection name and second parameter is variable which is storing the schema